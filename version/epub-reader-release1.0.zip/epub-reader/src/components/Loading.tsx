import React from 'react';
import { Book, Loader2 } from 'lucide-react';

interface LoadingProps {
  message?: string;
  size?: 'sm' | 'md' | 'lg';
  fullScreen?: boolean;
}

export const Loading: React.FC<LoadingProps> = ({ 
  message = '加载中...', 
  size = 'md',
  fullScreen = false 
}) => {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6',
    lg: 'w-8 h-8'
  };

  const containerClasses = fullScreen
    ? 'fixed inset-0 bg-white dark:bg-gray-900 flex items-center justify-center z-50'
    : 'flex items-center justify-center p-8';

  return (
    <div className={containerClasses}>
      <div className="flex flex-col items-center gap-4">
        {/* 加载图标 */}
        <div className="relative">
          <Book className={`${sizeClasses[size]} text-blue-600`} />
          <Loader2 className={`${sizeClasses[size]} text-blue-600 animate-spin absolute top-0 left-0`} />
        </div>
        
        {/* 加载文本 */}
        <p className="text-gray-600 dark:text-gray-400 text-sm font-medium">
          {message}
        </p>
        
        {/* 加载点动画 */}
        <div className="flex gap-1">
          <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
          <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
          <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
        </div>
      </div>
    </div>
  );
};

export const PageLoading: React.FC<{ message?: string }> = ({ message }) => (
  <Loading message={message} size="lg" fullScreen />
);

export const ComponentLoading: React.FC<{ message?: string }> = ({ message }) => (
  <Loading message={message} size="md" fullScreen={false} />
);

export const ButtonLoading: React.FC = () => (
  <Loader2 className="w-4 h-4 animate-spin" />
);