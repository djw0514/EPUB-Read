import React, { useState, useEffect } from 'react';
import { Plus, Grid, List, SortAsc, BookOpen } from 'lucide-react';
import { Book } from '../../lib/database';
import { useLibrary } from '../../hooks/useLibrary';
import { UploadArea } from './UploadArea';
import { BookCard } from './BookCard';
import { SearchBar } from './SearchBar';
import { DeleteConfirmDialog } from './DeleteConfirmDialog';

interface LibraryProps {
  onBookSelect: (book: Book) => void;
}

type SortOption = 'recent' | 'title' | 'author';
type ViewMode = 'grid' | 'list';

export const Library: React.FC<LibraryProps> = ({ onBookSelect }) => {
  const { 
    books, 
    loading, 
    error, 
    loadBooks, 
    addBook, 
    deleteBook, 
    searchBooks 
  } = useLibrary();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [showUpload, setShowUpload] = useState(false);
  const [bookToDelete, setBookToDelete] = useState<Book | null>(null);
  const [sortBy, setSortBy] = useState<SortOption>('recent');
  const [viewMode, setViewMode] = useState<ViewMode>('grid');

  // 初始加载
  useEffect(() => {
    loadBooks();
  }, [loadBooks]);

  // 搜索处理
  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (query.trim()) {
      searchBooks(query);
    } else {
      loadBooks();
    }
  };

  // 添加书籍
  const handleBookAdded = async (newBook: Book) => {
    await loadBooks();
    setShowUpload(false);
  };

  // 删除书籍
  const handleDeleteBook = (book: Book) => {
    setBookToDelete(book);
  };

  const confirmDelete = async () => {
    if (bookToDelete) {
      await deleteBook(bookToDelete.id!);
      setBookToDelete(null);
    }
  };

  const cancelDelete = () => {
    setBookToDelete(null);
  };

  // 排序书籍
  const sortedBooks = React.useMemo(() => {
    const sorted = [...books];
    switch (sortBy) {
      case 'title':
        return sorted.sort((a, b) => a.title.localeCompare(b.title, 'zh-CN'));
      case 'author':
        return sorted.sort((a, b) => a.author.localeCompare(b.author, 'zh-CN'));
      case 'recent':
      default:
        return sorted.sort((a, b) => new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime());
    }
  }, [books, sortBy]);

  // 错误处理
  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="text-red-500 mb-4">
            <BookOpen className="w-16 h-16 mx-auto mb-4 opacity-50" />
          </div>
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
            加载失败
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            {error}
          </p>
          <button
            onClick={loadBooks}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            重试
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* 顶部工具栏 */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* 标题 */}
            <div className="flex items-center gap-3">
              <BookOpen className="w-6 h-6 text-blue-600" />
              <h1 className="text-xl font-semibold text-gray-900 dark:text-white">
                我的书架
              </h1>
              <span className="text-sm text-gray-500 dark:text-gray-400">
                ({books.length} 本书)
              </span>
            </div>

            {/* 右侧操作 */}
            <div className="flex items-center gap-4">
              {/* 搜索栏 */}
              <SearchBar onSearch={handleSearch} />

              {/* 排序选择 */}
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
                className="
                  px-3 py-1 text-sm
                  border border-gray-300 dark:border-gray-600
                  rounded-md
                  bg-white dark:bg-gray-700
                  text-gray-900 dark:text-white
                  focus:ring-2 focus:ring-blue-500 focus:border-transparent
                "
              >
                <option value="recent">最近添加</option>
                <option value="title">按标题</option>
                <option value="author">按作者</option>
              </select>

              {/* 视图切换 */}
              <div className="flex border border-gray-300 dark:border-gray-600 rounded-md overflow-hidden">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 ${
                    viewMode === 'grid'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-600'
                  } transition-colors`}
                >
                  <Grid className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 ${
                    viewMode === 'list'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-600'
                  } transition-colors`}
                >
                  <List className="w-4 h-4" />
                </button>
              </div>

              {/* 添加按钮 */}
              <button
                onClick={() => setShowUpload(true)}
                className="
                  flex items-center gap-2 px-4 py-2
                  bg-blue-600 hover:bg-blue-700
                  text-white
                  rounded-lg
                  transition-colors
                  font-medium
                "
              >
                <Plus className="w-4 h-4" />
                添加书籍
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 上传区域模态框 */}
      {showUpload && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50">
          <div className="bg-white dark:bg-gray-800 rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                  添加新书籍
                </h2>
                <button
                  onClick={() => setShowUpload(false)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                >
                  ✕
                </button>
              </div>
              <UploadArea
                onBookAdded={handleBookAdded}
                onError={(error) => {
                  console.error(error);
                  // 这里可以添加错误提示
                }}
              />
            </div>
          </div>
        </div>
      )}

      {/* 主内容区域 */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        ) : books.length === 0 ? (
          <div className="text-center py-20">
            <BookOpen className="w-24 h-24 text-gray-300 dark:text-gray-600 mx-auto mb-6" />
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              书架为空
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              开始添加您的第一本 EPUB 书籍吧！
            </p>
            <button
              onClick={() => setShowUpload(true)}
              className="
                inline-flex items-center gap-2 px-6 py-3
                bg-blue-600 hover:bg-blue-700
                text-white
                rounded-lg
                transition-colors
                font-medium
              "
            >
              <Plus className="w-5 h-5" />
              添加书籍
            </button>
          </div>
        ) : (
          <div className={
            viewMode === 'grid'
              ? 'grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6'
              : 'space-y-4'
          }>
            {sortedBooks.map((book) => (
              <BookCard
                key={book.id}
                book={book}
                onRead={onBookSelect}
                onDelete={handleDeleteBook}
                searchTerm={searchQuery}
              />
            ))}
          </div>
        )}
      </div>

      {/* 删除确认对话框 */}
      <DeleteConfirmDialog
        book={bookToDelete}
        onConfirm={confirmDelete}
        onCancel={cancelDelete}
        isOpen={!!bookToDelete}
      />
    </div>
  );
};