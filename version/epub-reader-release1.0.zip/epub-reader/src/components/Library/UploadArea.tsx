import React, { useRef, useState } from 'react';
import { Upload, FileText, AlertCircle } from 'lucide-react';
import { useDragAndDrop } from '../../hooks/useLibrary';
import { validateEPUBFile, fileToBase64, parseEPUBMetaData, formatFileSize } from '../../utils/fileUtils';
import { DatabaseService } from '../../lib/database';

interface UploadAreaProps {
  onBookAdded: (book: any) => void;
  onError: (error: string) => void;
}

export const UploadArea: React.FC<UploadAreaProps> = ({ onBookAdded, onError }) => {
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { isDragOver, dragProps } = useDragAndDrop(handleFileDrop);

  async function handleFileDrop(files: FileList) {
    const file = files[0];
    if (!file) return;

    await processFile(file);
  }

  async function handleFileSelect(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;

    await processFile(file);
    
    // 清空输入，允许重复选择同一文件
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  }

  async function processFile(file: File) {
    // 验证文件
    const validation = validateEPUBFile(file);
    if (!validation.valid) {
      onError(validation.error || '文件验证失败');
      return;
    }

    setUploading(true);
    setUploadProgress(0);

    try {
      // 转换文件为base64
      setUploadProgress(25);
      const base64Data = await fileToBase64(file);

      // 解析EPUB元数据
      setUploadProgress(50);
      const metadata = await parseEPUBMetaData(base64Data);

      // 检查元数据是否有效
      if (!metadata.title || metadata.title === '未知标题') {
        throw new Error('无法解析书籍元数据，请确保文件是有效的EPUB格式');
      }

      // 保存到数据库
      setUploadProgress(75);
      const bookData = {
        title: metadata.title,
        author: metadata.author,
        cover: metadata.cover,
        fileData: base64Data,
        fileName: file.name,
        fileSize: file.size,
        addedAt: new Date()
      };

      const bookId = await DatabaseService.addBook(bookData);
      
      // 返回完整的书籍信息
      const newBook = {
        id: bookId,
        ...bookData
      };

      onBookAdded(newBook);
      setUploadProgress(100);
    } catch (error) {
      console.error('文件处理失败:', error);
      
      // 提供更详细的错误信息
      let errorMessage = '文件处理失败，请重试';
      
      if (error instanceof Error) {
        if (error.message.includes('EPUB')) {
          errorMessage = 'EPUB文件格式错误，请确保文件完整且格式正确';
        } else if (error.message.includes('元数据')) {
          errorMessage = '无法解析书籍信息，请检查EPUB文件是否损坏';
        } else {
          errorMessage = `处理失败: ${error.message}`;
        }
      }
      
      onError(errorMessage);
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  }

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-6">
      <div
        {...dragProps}
        className={`
          relative border-2 border-dashed rounded-xl p-12 text-center transition-all duration-200
          ${isDragOver 
            ? 'border-blue-400 bg-blue-50 dark:bg-blue-900/20' 
            : 'border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500'
          }
          ${uploading ? 'pointer-events-none opacity-75' : 'cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800/50'}
        `}
        onClick={!uploading ? handleUploadClick : undefined}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".epub"
          onChange={handleFileSelect}
          className="hidden"
        />

        {/* 上传图标 */}
        <div className="flex justify-center mb-4">
          {uploading ? (
            <div className="animate-spin">
              <Upload className="w-12 h-12 text-blue-500" />
            </div>
          ) : (
            <div className="relative">
              <FileText className="w-12 h-12 text-gray-400 dark:text-gray-500" />
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                <span className="text-xs text-white font-bold">+</span>
              </div>
            </div>
          )}
        </div>

        {/* 上传文本 */}
        <div className="space-y-2">
          {uploading ? (
            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-300">
                正在处理文件...
              </h3>
              
              {/* 进度条 */}
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                <div 
                  className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
              
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {uploadProgress}% 完成
              </p>
            </div>
          ) : (
            <div>
              <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-300">
                {isDragOver ? '松开鼠标添加书籍' : '添加 EPUB 书籍'}
              </h3>
              <p className="text-gray-500 dark:text-gray-400 mt-1">
                拖拽文件到此处，或 <span className="text-blue-500 hover:text-blue-600 font-medium">点击选择文件</span>
              </p>
              <p className="text-xs text-gray-400 dark:text-gray-500 mt-2">
                支持 EPUB 格式，文件大小不超过 100MB
              </p>
            </div>
          )}
        </div>

        {/* 拖拽覆盖层 */}
        {isDragOver && !uploading && (
          <div className="absolute inset-0 bg-blue-500/10 rounded-xl flex items-center justify-center">
            <div className="text-blue-600 dark:text-blue-400 font-semibold">
              释放以上传文件
            </div>
          </div>
        )}

        {/* 错误提示 */}
        {isDragOver && (
          <div className="absolute top-4 right-4">
            <AlertCircle className="w-5 h-5 text-blue-500" />
          </div>
        )}
      </div>

      {/* 支持的格式说明 */}
      <div className="mt-4 text-center">
        <p className="text-xs text-gray-400 dark:text-gray-500">
          支持的文件格式：EPUB
        </p>
      </div>
    </div>
  );
};