import React, { useState } from 'react';
import { Book, MoreVertical, Trash2, Clock, User } from 'lucide-react';
import { Book as BookType } from '../../lib/database';
import { formatDate, formatFileSize, truncateText } from '../../utils/fileUtils';

interface BookCardProps {
  book: BookType;
  onRead: (book: BookType) => void;
  onDelete: (book: BookType) => void;
  searchTerm?: string;
}

export const BookCard: React.FC<BookCardProps> = ({ 
  book, 
  onRead, 
  onDelete, 
  searchTerm = '' 
}) => {
  const [showMenu, setShowMenu] = useState(false);
  const [imageError, setImageError] = useState(false);

  const handleImageError = () => {
    setImageError(true);
  };

  const handleCardClick = () => {
    onRead(book);
  };

  const handleMenuClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowMenu(!showMenu);
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDelete(book);
    setShowMenu(false);
  };

  const highlightSearchTerm = (text: string, term: string) => {
    if (!term) return text;
    const regex = new RegExp(`(${term})`, 'gi');
    const parts = text.split(regex);
    return parts.map((part, index) => 
      regex.test(part) ? (
        <mark key={index} className="bg-yellow-200 dark:bg-yellow-800 px-1 rounded">
          {part}
        </mark>
      ) : part
    );
  };

  return (
    <div className="group relative bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:shadow-lg transition-all duration-200 cursor-pointer transform hover:-translate-y-1">
      {/* 书籍封面 */}
      <div className="aspect-[3/4] relative overflow-hidden rounded-t-xl bg-gray-100 dark:bg-gray-700">
        {book.cover && !imageError ? (
          <img
            src={`data:image/jpeg;base64,${book.cover}`}
            alt={book.title}
            className="w-full h-full object-cover"
            onError={handleImageError}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Book className="w-16 h-16 text-gray-400 dark:text-gray-500" />
          </div>
        )}

        {/* 悬停时的操作按钮 */}
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-200 flex items-center justify-center">
          <button
            onClick={handleCardClick}
            className="opacity-0 group-hover:opacity-100 bg-white dark:bg-gray-800 text-gray-900 dark:text-white px-4 py-2 rounded-lg font-medium transition-all duration-200 hover:bg-gray-100 dark:hover:bg-gray-700"
          >
            开始阅读
          </button>
        </div>

        {/* 更多操作菜单按钮 */}
        <button
          onClick={handleMenuClick}
          className="absolute top-2 right-2 w-8 h-8 bg-black bg-opacity-50 text-white rounded-full opacity-0 group-hover:opacity-100 transition-all duration-200 hover:bg-opacity-70 flex items-center justify-center"
        >
          <MoreVertical className="w-4 h-4" />
        </button>

        {/* 下拉菜单 */}
        {showMenu && (
          <>
            {/* 遮罩层 */}
            <div 
              className="fixed inset-0 z-10"
              onClick={() => setShowMenu(false)}
            />
            
            {/* 菜单内容 */}
            <div className="absolute top-10 right-2 z-20 bg-white dark:bg-gray-800 rounded-lg shadow-lg py-1 min-w-[120px]">
              <button
                onClick={handleDelete}
                className="w-full px-3 py-2 text-left text-sm text-red-600 dark:text-red-400 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                删除
              </button>
            </div>
          </>
        )}
      </div>

      {/* 书籍信息 */}
      <div className="p-4">
        {/* 标题 */}
        <h3 className="font-semibold text-gray-900 dark:text-white text-sm leading-tight mb-2 line-clamp-2">
          {highlightSearchTerm(book.title, searchTerm)}
        </h3>

        {/* 作者 */}
        <div className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400 mb-2">
          <User className="w-3 h-3" />
          <span className="truncate">
            {highlightSearchTerm(book.author, searchTerm)}
          </span>
        </div>

        {/* 添加时间 */}
        <div className="flex items-center gap-1 text-xs text-gray-400 dark:text-gray-500 mb-2">
          <Clock className="w-3 h-3" />
          <span>{formatDate(book.addedAt)}</span>
        </div>

        {/* 文件大小 */}
        <div className="text-xs text-gray-400 dark:text-gray-500">
          {formatFileSize(book.fileSize)}
        </div>
      </div>

      {/* 点击区域 */}
      <div 
        className="absolute inset-0 z-5"
        onClick={handleCardClick}
        style={{ zIndex: 1 }}
      />
    </div>
  );
};