import React, { useState, useEffect } from 'react';
import { Search, X } from 'lucide-react';

interface SearchBarProps {
  onSearch: (query: string) => void;
  placeholder?: string;
}

export const SearchBar: React.FC<SearchBarProps> = ({ 
  onSearch, 
  placeholder = "搜索书籍标题或作者..." 
}) => {
  const [query, setQuery] = useState('');

  // 防抖搜索
  useEffect(() => {
    const timer = setTimeout(() => {
      onSearch(query);
    }, 300);

    return () => clearTimeout(timer);
  }, [query, onSearch]);

  const handleClear = () => {
    setQuery('');
    onSearch('');
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setQuery(e.target.value);
  };

  return (
    <div className="relative w-full max-w-md">
      <div className="relative">
        {/* 搜索图标 */}
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-4 w-4 text-gray-400" />
        </div>

        {/* 输入框 */}
        <input
          type="text"
          value={query}
          onChange={handleInputChange}
          placeholder={placeholder}
          className="
            block w-full pl-10 pr-10 py-2 
            border border-gray-300 dark:border-gray-600
            rounded-lg 
            bg-white dark:bg-gray-800
            text-gray-900 dark:text-white
            placeholder-gray-500 dark:placeholder-gray-400
            focus:ring-2 focus:ring-blue-500 focus:border-transparent
            transition-colors duration-200
          "
        />

        {/* 清除按钮 */}
        {query && (
          <button
            onClick={handleClear}
            className="
              absolute inset-y-0 right-0 pr-3 
              flex items-center
              text-gray-400 hover:text-gray-600 dark:hover:text-gray-300
              transition-colors duration-200
            "
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* 搜索提示 */}
      {query && (
        <div className="absolute top-full left-0 right-0 mt-1 text-xs text-gray-500 dark:text-gray-400">
          搜索: "{query}"
        </div>
      )}
    </div>
  );
};