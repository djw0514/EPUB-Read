import React from 'react';
import { AlertTriangle, Book } from 'lucide-react';
import { Book as BookType } from '../../lib/database';
import { formatFileSize } from '../../utils/fileUtils';

interface DeleteConfirmDialogProps {
  book: BookType | null;
  onConfirm: () => void;
  onCancel: () => void;
  isOpen: boolean;
}

export const DeleteConfirmDialog: React.FC<DeleteConfirmDialogProps> = ({
  book,
  onConfirm,
  onCancel,
  isOpen
}) => {
  if (!isOpen || !book) return null;

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onCancel();
    }
  };

  const handleConfirm = () => {
    onConfirm();
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50"
      onClick={handleBackdropClick}
    >
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-md w-full p-6 transform transition-all">
        {/* 图标 */}
        <div className="flex items-center justify-center w-12 h-12 mx-auto mb-4 bg-red-100 dark:bg-red-900/20 rounded-full">
          <AlertTriangle className="w-6 h-6 text-red-600 dark:text-red-400" />
        </div>

        {/* 标题 */}
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white text-center mb-2">
          确认删除书籍
        </h3>

        {/* 书籍信息 */}
        <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 mb-6">
          <div className="flex items-start gap-3">
            {/* 封面 */}
            <div className="flex-shrink-0 w-12 h-16 bg-gray-200 dark:bg-gray-600 rounded overflow-hidden">
              {book.cover ? (
                <img
                  src={`data:image/jpeg;base64,${book.cover}`}
                  alt={book.title}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Book className="w-6 h-6 text-gray-400" />
                </div>
              )}
            </div>

            {/* 书籍详情 */}
            <div className="flex-1 min-w-0">
              <h4 className="font-medium text-gray-900 dark:text-white text-sm leading-tight mb-1">
                {book.title}
              </h4>
              <p className="text-sm text-gray-600 dark:text-gray-300 mb-1">
                {book.author}
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {formatFileSize(book.fileSize)}
              </p>
            </div>
          </div>
        </div>

        {/* 警告信息 */}
        <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg p-3 mb-6">
          <p className="text-sm text-amber-800 dark:text-amber-200">
            <strong>注意：</strong>此操作将永久删除书籍及其阅读记录，无法撤销。
          </p>
        </div>

        {/* 按钮 */}
        <div className="flex gap-3">
          <button
            onClick={onCancel}
            className="
              flex-1 px-4 py-2 
              border border-gray-300 dark:border-gray-600
              text-gray-700 dark:text-gray-300
              bg-white dark:bg-gray-700
              rounded-lg
              hover:bg-gray-50 dark:hover:bg-gray-600
              transition-colors duration-200
              font-medium
            "
          >
            取消
          </button>
          <button
            onClick={handleConfirm}
            className="
              flex-1 px-4 py-2
              bg-red-600 hover:bg-red-700
              text-white
              rounded-lg
              transition-colors duration-200
              font-medium
            "
          >
            确认删除
          </button>
        </div>
      </div>
    </div>
  );
};