import React from 'react';
import { Type, Minus, Plus } from 'lucide-react';
import { ReaderSettings } from '../../lib/database';

interface FontSettingsProps {
  settings: ReaderSettings;
  onChange: (changes: Partial<ReaderSettings>) => void;
  loading: boolean;
}

const fontFamilies = [
  { value: 'serif', label: '衬线字体', preview: 'AaBbCc 苹果微软谷歌' },
  { value: 'sans-serif', label: '无衬线字体', preview: 'AaBbCc 苹果微软谷歌' },
  { value: 'monospace', label: '等宽字体', preview: 'AaBbCc 苹果微软谷歌' },
  { value: 'georgia', label: 'Georgia', preview: 'AaBbCc 苹果微软谷歌' },
  { value: 'verdana', label: 'Verdana', preview: 'AaBbCc 苹果微软谷歌' }
];

export const FontSettings: React.FC<FontSettingsProps> = ({
  settings,
  onChange,
  loading
}) => {
  const handleFontSizeChange = (delta: number) => {
    const newSize = Math.max(12, Math.min(32, settings.fontSize + delta));
    onChange({ fontSize: newSize });
  };

  const handleFontFamilyChange = (fontFamily: string) => {
    onChange({ fontFamily });
  };

  const fontSizePreview = {
    fontSize: `${settings.fontSize}px`,
    fontFamily: getFontFamily(settings.fontFamily),
    lineHeight: settings.lineHeight
  };

  return (
    <div className="p-6 space-y-6">
      {/* 标题 */}
      <div className="flex items-center gap-2 mb-4">
        <Type className="w-5 h-5 text-blue-600" />
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          字体设置
        </h3>
      </div>

      {/* 字体大小 */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
            字体大小
          </label>
          <span className="text-sm text-gray-500 dark:text-gray-400">
            {settings.fontSize}px
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => handleFontSizeChange(-2)}
            disabled={settings.fontSize <= 12 || loading}
            className="p-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <Minus className="w-4 h-4" />
          </button>

          <div className="flex-1">
            <input
              type="range"
              min="12"
              max="32"
              value={settings.fontSize}
              onChange={(e) => onChange({ fontSize: parseInt(e.target.value) })}
              disabled={loading}
              className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
            />
          </div>

          <button
            onClick={() => handleFontSizeChange(2)}
            disabled={settings.fontSize >= 32 || loading}
            className="p-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>

        <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
          <span>12px</span>
          <span>32px</span>
        </div>
      </div>

      {/* 字体预览 */}
      <div className="space-y-3">
        <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
          预览效果
        </label>
        <div 
          className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg border-2 border-dashed border-gray-300 dark:border-gray-600"
          style={fontSizePreview}
        >
          <p className="mb-2">
            这是一段示例文本，用来预览字体设置的效果。您可以调整字体大小和类型来获得最佳的阅读体验。
          </p>
          <p className="text-gray-600 dark:text-gray-400">
            The quick brown fox jumps over the lazy dog.
          </p>
        </div>
      </div>

      {/* 字体类型 */}
      <div className="space-y-3">
        <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
          字体类型
        </label>
        <div className="grid grid-cols-1 gap-2">
          {fontFamilies.map((font) => (
            <button
              key={font.value}
              onClick={() => handleFontFamilyChange(font.value)}
              disabled={loading}
              className={`
                p-3 text-left border rounded-lg transition-all duration-200
                ${settings.fontFamily === font.value
                  ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                  : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500 hover:bg-gray-50 dark:hover:bg-gray-700/50'
                }
                disabled:opacity-50 disabled:cursor-not-allowed
              `}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-medium text-gray-900 dark:text-white">
                  {font.label}
                </span>
                {settings.fontFamily === font.value && (
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                )}
              </div>
              <div 
                className="text-sm text-gray-600 dark:text-gray-400"
                style={{ fontFamily: getFontFamily(font.value) }}
              >
                {font.preview}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* 快捷设置 */}
      <div className="space-y-3">
        <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
          快捷设置
        </label>
        <div className="flex gap-2">
          <button
            onClick={() => onChange({ fontSize: 14, fontFamily: 'serif' })}
            disabled={loading}
            className="flex-1 px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors disabled:opacity-50"
          >
            小号字体
          </button>
          <button
            onClick={() => onChange({ fontSize: 16, fontFamily: 'serif' })}
            disabled={loading}
            className="flex-1 px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors disabled:opacity-50"
          >
            标准字体
          </button>
          <button
            onClick={() => onChange({ fontSize: 18, fontFamily: 'sans-serif' })}
            disabled={loading}
            className="flex-1 px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors disabled:opacity-50"
          >
            大号字体
          </button>
        </div>
      </div>
    </div>
  );
};

// 工具函数
function getFontFamily(fontFamily: string): string {
  const fontMap: { [key: string]: string } = {
    'serif': '"Times New Roman", serif',
    'sans-serif': 'Arial, Helvetica, sans-serif',
    'monospace': '"Courier New", monospace',
    'georgia': 'Georgia, serif',
    'verdana': 'Verdana, sans-serif'
  };
  return fontMap[fontFamily] || fontMap['serif'];
}