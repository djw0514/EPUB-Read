import React, { useState } from 'react';
import { X, Type, Palette, Layout, RotateCcw, Save } from 'lucide-react';
import { useReaderSettings } from '../../hooks/useLibrary';
import { FontSettings } from './FontSettings';
import { ThemeSettings } from './ThemeSettings';
import { LayoutSettings } from './LayoutSettings';

interface SettingsPanelProps {
  onClose: () => void;
  isOpen: boolean;
}

type SettingsTab = 'font' | 'theme' | 'layout';

export const SettingsPanel: React.FC<SettingsPanelProps> = ({ onClose, isOpen }) => {
  const { settings, saveSettings, resetSettings, loading } = useReaderSettings();
  const [activeTab, setActiveTab] = useState<SettingsTab>('font');
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  // 监听设置变化
  const handleSettingChange = (changes: any) => {
    setHasUnsavedChanges(true);
    // 实时应用设置
    saveSettings(changes);
  };

  const handleReset = async () => {
    try {
      await resetSettings();
      setHasUnsavedChanges(false);
    } catch (error) {
      console.error('重置设置失败:', error);
    }
  };

  const handleClose = () => {
    if (hasUnsavedChanges) {
      const shouldSave = window.confirm('您有未保存的更改，确定要关闭吗？');
      if (!shouldSave) return;
    }
    onClose();
  };

  const tabs = [
    { id: 'font' as SettingsTab, label: '字体', icon: Type },
    { id: 'theme' as SettingsTab, label: '主题', icon: Palette },
    { id: 'layout' as SettingsTab, label: '排版', icon: Layout }
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-hidden settings-panel">
        {/* 头部 */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center gap-3">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              阅读设置
            </h2>
            {hasUnsavedChanges && (
              <span className="text-xs bg-orange-100 text-orange-700 dark:bg-orange-900/20 dark:text-orange-300 px-2 py-1 rounded">
                未保存
              </span>
            )}
          </div>
          <button
            onClick={handleClose}
            className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex h-96">
          {/* 侧边标签栏 */}
          <div className="w-32 border-r border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50">
            <nav className="p-2 space-y-1">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`
                      w-full flex items-center gap-2 px-3 py-2 text-sm rounded-lg transition-colors
                      ${activeTab === tab.id
                        ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/20 dark:text-blue-300'
                        : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-600'
                      }
                    `}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* 设置内容区域 */}
          <div className="flex-1 overflow-y-auto">
            {activeTab === 'font' && (
              <FontSettings
                settings={settings}
                onChange={handleSettingChange}
                loading={loading}
              />
            )}
            
            {activeTab === 'theme' && (
              <ThemeSettings
                settings={settings}
                onChange={handleSettingChange}
                loading={loading}
              />
            )}
            
            {activeTab === 'layout' && (
              <LayoutSettings
                settings={settings}
                onChange={handleSettingChange}
                loading={loading}
              />
            )}
          </div>
        </div>

        {/* 底部操作栏 */}
        <div className="flex items-center justify-between p-6 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50">
          <button
            onClick={handleReset}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-600 rounded-lg transition-colors disabled:opacity-50"
          >
            <RotateCcw className="w-4 h-4" />
            重置为默认
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={handleClose}
              className="px-4 py-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors"
            >
              关闭
            </button>
            <button
              onClick={() => {
                setHasUnsavedChanges(false);
                handleClose();
              }}
              disabled={loading}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              {loading ? '保存中...' : '保存'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};