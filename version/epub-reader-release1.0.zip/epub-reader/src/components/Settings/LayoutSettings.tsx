import React from 'react';
import { Layout, Monitor, Smartphone } from 'lucide-react';
import { ReaderSettings } from '../../lib/database';

interface LayoutSettingsProps {
  settings: ReaderSettings;
  onChange: (changes: Partial<ReaderSettings>) => void;
  loading: boolean;
}

export const LayoutSettings: React.FC<LayoutSettingsProps> = ({
  settings,
  onChange,
  loading
}) => {
  const handleLineHeightChange = (lineHeight: number) => {
    onChange({ lineHeight });
  };

  const handleMarginChange = (margin: number) => {
    onChange({ margin });
  };

  const handleViewModeChange = (viewMode: 'single' | 'spread') => {
    onChange({ viewMode });
  };

  return (
    <div className="p-6 space-y-6">
      {/* 标题 */}
      <div className="flex items-center gap-2 mb-4">
        <Layout className="w-5 h-5 text-blue-600" />
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          排版设置
        </h3>
      </div>

      {/* 行高设置 */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
            行高
          </label>
          <span className="text-sm text-gray-500 dark:text-gray-400">
            {settings.lineHeight}
          </span>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs text-gray-400 w-8">紧密</span>
          <div className="flex-1">
            <input
              type="range"
              min="1.2"
              max="2.0"
              step="0.1"
              value={settings.lineHeight}
              onChange={(e) => handleLineHeightChange(parseFloat(e.target.value))}
              disabled={loading}
              className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
            />
          </div>
          <span className="text-xs text-gray-400 w-8">宽松</span>
        </div>

        <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg border-2 border-dashed border-gray-300 dark:border-gray-600">
          <div 
            className="text-gray-900 dark:text-white"
            style={{ 
              lineHeight: settings.lineHeight,
              fontSize: '14px'
            }}
          >
            这是一段示例文本，用来预览行高设置的效果。适当的行高可以让文字更易读，减少视觉疲劳。
          </div>
        </div>
      </div>

      {/* 页边距设置 */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
            页边距
          </label>
          <span className="text-sm text-gray-500 dark:text-gray-400">
            {settings.margin}px
          </span>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs text-gray-400 w-8">最小</span>
          <div className="flex-1">
            <input
              type="range"
              min="20"
              max="80"
              step="5"
              value={settings.margin}
              onChange={(e) => handleMarginChange(parseInt(e.target.value))}
              disabled={loading}
              className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
            />
          </div>
          <span className="text-xs text-gray-400 w-8">最大</span>
        </div>

        <div className="relative">
          <div className="bg-gray-200 dark:bg-gray-600 p-4 rounded-lg">
            <div 
              className="bg-white dark:bg-gray-800 p-4 rounded border-2 border-dashed border-gray-300 dark:border-gray-500"
              style={{ margin: `${settings.margin}px` }}
            >
              <div className="text-sm text-gray-600 dark:text-gray-400 text-center">
                内容区域
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 视图模式 */}
      <div className="space-y-3">
        <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
          视图模式
        </label>
        
        <div className="grid grid-cols-2 gap-3">
          {/* 单页模式 */}
          <button
            onClick={() => handleViewModeChange('single')}
            disabled={loading}
            className={`
              relative p-4 border rounded-xl text-left transition-all duration-200
              ${settings.viewMode === 'single'
                ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
              }
              disabled:opacity-50 disabled:cursor-not-allowed
            `}
          >
            {settings.viewMode === 'single' && (
              <div className="absolute top-2 right-2 w-2 h-2 bg-blue-500 rounded-full"></div>
            )}
            
            <div className="flex items-center gap-3 mb-2">
              <Smartphone className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              <span className="font-medium text-gray-900 dark:text-white">
                单页模式
              </span>
            </div>
            
            <p className="text-xs text-gray-600 dark:text-gray-400 mb-3">
              适合移动设备，一次显示一页内容
            </p>
            
            {/* 预览 */}
            <div className="bg-gray-100 dark:bg-gray-700 rounded p-2">
              <div className="bg-white dark:bg-gray-800 h-8 rounded border mb-1"></div>
              <div className="bg-white dark:bg-gray-800 h-2 rounded mb-1"></div>
              <div className="bg-white dark:bg-gray-800 h-2 rounded mb-1"></div>
              <div className="bg-white dark:bg-gray-800 h-2 rounded w-3/4"></div>
            </div>
          </button>

          {/* 双页模式 */}
          <button
            onClick={() => handleViewModeChange('spread')}
            disabled={loading}
            className={`
              relative p-4 border rounded-xl text-left transition-all duration-200
              ${settings.viewMode === 'spread'
                ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
              }
              disabled:opacity-50 disabled:cursor-not-allowed
            `}
          >
            {settings.viewMode === 'spread' && (
              <div className="absolute top-2 right-2 w-2 h-2 bg-blue-500 rounded-full"></div>
            )}
            
            <div className="flex items-center gap-3 mb-2">
              <Monitor className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              <span className="font-medium text-gray-900 dark:text-white">
                双页模式
              </span>
            </div>
            
            <p className="text-xs text-gray-600 dark:text-gray-400 mb-3">
              适合桌面设备，同时显示两页内容
            </p>
            
            {/* 预览 */}
            <div className="bg-gray-100 dark:bg-gray-700 rounded p-2">
              <div className="flex gap-1">
                <div className="flex-1">
                  <div className="bg-white dark:bg-gray-800 h-6 rounded border mb-1"></div>
                  <div className="bg-white dark:bg-gray-800 h-1.5 rounded mb-1"></div>
                  <div className="bg-white dark:bg-gray-800 h-1.5 rounded mb-1"></div>
                  <div className="bg-white dark:bg-gray-800 h-1.5 rounded w-2/3"></div>
                </div>
                <div className="flex-1">
                  <div className="bg-white dark:bg-gray-800 h-6 rounded border mb-1"></div>
                  <div className="bg-white dark:bg-gray-800 h-1.5 rounded mb-1"></div>
                  <div className="bg-white dark:bg-gray-800 h-1.5 rounded mb-1"></div>
                  <div className="bg-white dark:bg-gray-800 h-1.5 rounded w-2/3"></div>
                </div>
              </div>
            </div>
          </button>
        </div>
      </div>

      {/* 预设方案 */}
      <div className="space-y-3">
        <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
          预设方案
        </label>
        <div className="grid grid-cols-1 gap-2">
          <button
            onClick={() => onChange({ 
              lineHeight: 1.5, 
              margin: 40, 
              viewMode: 'single' 
            })}
            disabled={loading}
            className="p-3 text-left border border-gray-200 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors disabled:opacity-50"
          >
            <div className="font-medium text-gray-900 dark:text-white">标准阅读</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">行高 1.5, 边距 40px, 单页模式</div>
          </button>
          
          <button
            onClick={() => onChange({ 
              lineHeight: 1.8, 
              margin: 60, 
              viewMode: 'spread' 
            })}
            disabled={loading}
            className="p-3 text-left border border-gray-200 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors disabled:opacity-50"
          >
            <div className="font-medium text-gray-900 dark:text-white">宽松阅读</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">行高 1.8, 边距 60px, 双页模式</div>
          </button>
          
          <button
            onClick={() => onChange({ 
              lineHeight: 1.4, 
              margin: 30, 
              viewMode: 'single' 
            })}
            disabled={loading}
            className="p-3 text-left border border-gray-200 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors disabled:opacity-50"
          >
            <div className="font-medium text-gray-900 dark:text-white">紧凑阅读</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">行高 1.4, 边距 30px, 单页模式</div>
          </button>
        </div>
      </div>

      {/* 响应式提示 */}
      <div className="p-4 bg-amber-50 dark:bg-amber-900/20 rounded-lg border border-amber-200 dark:border-amber-800">
        <h4 className="text-sm font-medium text-amber-900 dark:text-amber-100 mb-2">
          📱 响应式提示
        </h4>
        <ul className="text-xs text-amber-800 dark:text-amber-200 space-y-1">
          <li>• 移动设备建议使用单页模式，触摸操作更便捷</li>
          <li>• 桌面设备推荐双页模式，充分利用屏幕空间</li>
          <li>• 可根据阅读习惯调整行高和边距</li>
        </ul>
      </div>
    </div>
  );
};