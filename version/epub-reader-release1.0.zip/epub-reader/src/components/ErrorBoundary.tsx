import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

const serializeError = (error: any) => {
  if (error instanceof Error) {
    return {
      message: error.message,
      stack: error.stack || 'No stack trace available'
    };
  }
  return {
    message: 'Unknown error occurred',
    stack: JSON.stringify(error, null, 2)
  };
};

export class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean; error: any }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
  }

  handleReload = () => {
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      const { message, stack } = serializeError(this.state.error);
      
      return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 max-w-lg w-full">
            <div className="flex items-center gap-3 mb-4">
              <AlertTriangle className="w-6 h-6 text-red-500" />
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                应用遇到了问题
              </h2>
            </div>
            
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              很抱歉，EPUB阅读器遇到了一个错误。请尝试刷新页面或重新加载应用。
            </p>
            
            <div className="space-y-3">
              <button
                onClick={this.handleReload}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
              >
                <RefreshCw className="w-4 h-4" />
                刷新页面
              </button>
              
              <details className="mt-4">
                <summary className="cursor-pointer text-sm text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200">
                  查看错误详情
                </summary>
                <pre className="mt-2 text-xs bg-gray-100 dark:bg-gray-700 p-3 rounded overflow-auto text-gray-800 dark:text-gray-200">
                  {message}
                  {stack && (
                    <>
                      {('\n' + stack)}
                    </>
                  )}
                </pre>
              </details>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
