import React, { useState, useCallback } from 'react';
import { CheckCircle, XCircle, AlertCircle, Info, X } from 'lucide-react';

type NotificationType = 'success' | 'error' | 'warning' | 'info';

interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message?: string;
  duration?: number;
}

interface NotificationState {
  notifications: Notification[];
}

class NotificationManager {
  private listeners: Array<(notifications: Notification[]) => void> = [];
  private state: NotificationState = { notifications: [] };

  subscribe(listener: (notifications: Notification[]) => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach(listener => listener(this.state.notifications));
  }

  private add(notification: Omit<Notification, 'id'>) {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 9);
    const newNotification = { ...notification, id };
    this.state.notifications.push(newNotification);
    this.notify();

    // 自动移除
    if (notification.duration !== 0) {
      setTimeout(() => {
        this.remove(id);
      }, notification.duration || 3000);
    }

    return id;
  }

  remove(id: string) {
    this.state.notifications = this.state.notifications.filter(n => n.id !== id);
    this.notify();
  }

  success(title: string, message?: string, duration?: number) {
    return this.add({ type: 'success', title, message, duration });
  }

  error(title: string, message?: string, duration?: number) {
    return this.add({ type: 'error', title, message, duration: duration || 5000 });
  }

  warning(title: string, message?: string, duration?: number) {
    return this.add({ type: 'warning', title, message, duration });
  }

  info(title: string, message?: string, duration?: number) {
    return this.add({ type: 'info', title, message, duration });
  }

  clear() {
    this.state.notifications = [];
    this.notify();
  }
}

export const notificationManager = new NotificationManager();

export const NotificationContainer: React.FC = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  React.useEffect(() => {
    const unsubscribe = notificationManager.subscribe(setNotifications);
    return unsubscribe;
  }, []);

  const getIcon = (type: NotificationType) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="w-5 h-5" />;
      case 'error':
        return <XCircle className="w-5 h-5" />;
      case 'warning':
        return <AlertCircle className="w-5 h-5" />;
      case 'info':
        return <Info className="w-5 h-5" />;
      default:
        return <Info className="w-5 h-5" />;
    }
  };

  const getColors = (type: NotificationType) => {
    switch (type) {
      case 'success':
        return 'bg-green-50 border-green-200 text-green-800 dark:bg-green-900/20 dark:border-green-800 dark:text-green-200';
      case 'error':
        return 'bg-red-50 border-red-200 text-red-800 dark:bg-red-900/20 dark:border-red-800 dark:text-red-200';
      case 'warning':
        return 'bg-yellow-50 border-yellow-200 text-yellow-800 dark:bg-yellow-900/20 dark:border-yellow-800 dark:text-yellow-200';
      case 'info':
        return 'bg-blue-50 border-blue-200 text-blue-800 dark:bg-blue-900/20 dark:border-blue-800 dark:text-blue-200';
      default:
        return 'bg-gray-50 border-gray-200 text-gray-800 dark:bg-gray-900/20 dark:border-gray-800 dark:text-gray-200';
    }
  };

  const getIconColor = (type: NotificationType) => {
    switch (type) {
      case 'success':
        return 'text-green-600 dark:text-green-400';
      case 'error':
        return 'text-red-600 dark:text-red-400';
      case 'warning':
        return 'text-yellow-600 dark:text-yellow-400';
      case 'info':
        return 'text-blue-600 dark:text-blue-400';
      default:
        return 'text-gray-600 dark:text-gray-400';
    }
  };

  if (notifications.length === 0) return null;

  return (
    <div className="fixed top-4 right-4 z-50 space-y-2">
      {notifications.map((notification) => (
        <div
          key={notification.id}
          className={`
            max-w-sm w-full border rounded-lg p-4 shadow-lg transform transition-all duration-300 ease-in-out
            ${getColors(notification.type)}
          `}
        >
          <div className="flex items-start gap-3">
            <div className={`flex-shrink-0 ${getIconColor(notification.type)}`}>
              {getIcon(notification.type)}
            </div>
            
            <div className="flex-1 min-w-0">
              <h4 className="font-medium text-sm">
                {notification.title}
              </h4>
              {notification.message && (
                <p className="mt-1 text-sm opacity-90">
                  {notification.message}
                </p>
              )}
            </div>
            
            <button
              onClick={() => notificationManager.remove(notification.id)}
              className="flex-shrink-0 opacity-70 hover:opacity-100 transition-opacity"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

// 全局显示通知的便捷函数
export const showNotification = {
  success: (title: string, message?: string, duration?: number) => {
    notificationManager.success(title, message, duration);
  },
  error: (title: string, message?: string, duration?: number) => {
    notificationManager.error(title, message, duration);
  },
  warning: (title: string, message?: string, duration?: number) => {
    notificationManager.warning(title, message, duration);
  },
  info: (title: string, message?: string, duration?: number) => {
    notificationManager.info(title, message, duration);
  }
};