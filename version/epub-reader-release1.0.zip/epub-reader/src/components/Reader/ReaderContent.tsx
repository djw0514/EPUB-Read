import React, { useEffect, useRef } from 'react';
import ePub from 'epubjs';
import { ReaderSettings } from '../../lib/database';

interface ReaderContentProps {
  book: any;
  settings: ReaderSettings;
  onNextPage: () => void;
  onPrevPage: () => void;
}

export const ReaderContent: React.FC<ReaderContentProps> = ({
  book,
  settings,
  onNextPage,
  onPrevPage
}) => {
  const viewerRef = useRef<HTMLDivElement>(null);
  const bookRef = useRef<any>(null);

  useEffect(() => {
    if (!viewerRef.current || !book) return;

    const initReader = async () => {
      try {
        // 清理之前的渲染
        if (bookRef.current) {
          bookRef.current.destroy();
        }

        // 创建新的渲染器
        const rendition = book.renderTo(viewerRef.current, {
          width: '100%',
          height: '100%',
          spread: settings.viewMode === 'spread' ? 'always' : 'none',
          flow: 'paginated' // 或 'scrolled-doc'
        });

        // 应用主题
        rendition.themes.register('default', {
          body: {
            'font-size': `${settings.fontSize}px`,
            'line-height': settings.lineHeight,
            'font-family': getFontFamily(settings.fontFamily),
            'margin': `${settings.margin}px`,
            'padding': '0',
            'color': getTextColor(settings.theme),
            'background-color': getBackgroundColor(settings.theme)
          },
          'p': {
            'margin-bottom': '1em',
            'text-indent': '2em'
          },
          'h1, h2, h3, h4, h5, h6': {
            'margin-top': '1em',
            'margin-bottom': '0.5em',
            'font-weight': 'bold'
          },
          'blockquote': {
            'margin': '1em 0',
            'padding-left': '1em',
            'border-left': '4px solid #ccc',
            'font-style': 'italic'
          },
          'img': {
            'max-width': '100%',
            'height': 'auto'
          }
        });

        // 选择主题
        rendition.themes.select('default');

        // 渲染当前页面
        await rendition.display();

        bookRef.current = rendition;

        // 监听位置变化
        rendition.on('relocated', (location: any) => {
          console.log('位置变化:', location);
        });

        // 监听渲染完成
        rendition.on('rendered', (section: any) => {
          console.log('渲染完成:', section);
        });

      } catch (error) {
        console.error('初始化阅读器失败:', error);
      }
    };

    initReader();

    return () => {
      if (bookRef.current) {
        bookRef.current.destroy();
      }
    };
  }, [book, settings]);

  // 应用设置变化
  useEffect(() => {
    if (bookRef.current) {
      try {
        const rendition = bookRef.current;
        
        // 重新渲染以应用新设置
        rendition.themes.default({
          'body': {
            'font-size': `${settings.fontSize}px`,
            'line-height': settings.lineHeight,
            'font-family': getFontFamily(settings.fontFamily),
            'margin': `${settings.margin}px`,
            'color': getTextColor(settings.theme),
            'background-color': getBackgroundColor(settings.theme)
          }
        });

        rendition.display();
      } catch (error) {
        console.error('应用设置失败:', error);
      }
    }
  }, [settings]);

  // 键盘导航
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowLeft':
        case 'ArrowUp':
          e.preventDefault();
          onPrevPage();
          break;
        case 'ArrowRight':
        case 'ArrowDown':
        case ' ':
          e.preventDefault();
          onNextPage();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onNextPage, onPrevPage]);

  return (
    <div className="h-full w-full relative overflow-hidden">
      {/* EPUB渲染容器 */}
      <div 
        ref={viewerRef}
        className="h-full w-full relative"
        style={{
          backgroundColor: getBackgroundColor(settings.theme)
        }}
      />
      
      {/* 页面指示器 */}
      <div className="absolute bottom-4 right-4 z-10 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-xs">
        <div className="flex items-center gap-1">
          <div className="w-1 h-1 bg-white rounded-full opacity-50"></div>
          <div className="w-1 h-1 bg-white rounded-full opacity-75"></div>
          <div className="w-1 h-1 bg-white rounded-full"></div>
        </div>
      </div>

      {/* 翻页提示 */}
      <div className="absolute inset-0 pointer-events-none">
        {/* 左半部分 - 上一页 */}
        <div 
          className="absolute left-0 top-0 w-1/3 h-full cursor-pointer hover:bg-blue-500 hover:bg-opacity-10 transition-colors pointer-events-auto"
          onClick={onPrevPage}
        >
          <div className="absolute left-4 top-1/2 transform -translate-y-1/2 opacity-0 hover:opacity-100 transition-opacity">
            <div className="bg-black bg-opacity-50 text-white p-2 rounded">
              ←
            </div>
          </div>
        </div>

        {/* 右半部分 - 下一页 */}
        <div 
          className="absolute right-0 top-0 w-1/3 h-full cursor-pointer hover:bg-blue-500 hover:bg-opacity-10 transition-colors pointer-events-auto"
          onClick={onNextPage}
        >
          <div className="absolute right-4 top-1/2 transform -translate-y-1/2 opacity-0 hover:opacity-100 transition-opacity">
            <div className="bg-black bg-opacity-50 text-white p-2 rounded">
              →
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// 工具函数
function getFontFamily(fontFamily: string): string {
  const fontMap: { [key: string]: string } = {
    'serif': '"Times New Roman", serif',
    'sans-serif': 'Arial, Helvetica, sans-serif',
    'monospace': '"Courier New", monospace',
    'georgia': 'Georgia, serif',
    'verdana': 'Verdana, sans-serif'
  };
  return fontMap[fontFamily] || fontMap['serif'];
}

function getTextColor(theme: string): string {
  const colorMap: { [key: string]: string } = {
    'light': '#000000',
    'dark': '#ffffff',
    'sepia': '#5c4033'
  };
  return colorMap[theme] || colorMap['light'];
}

function getBackgroundColor(theme: string): string {
  const colorMap: { [key: string]: string } = {
    'light': '#ffffff',
    'dark': '#1a1a1a',
    'sepia': '#f4f1e8'
  };
  return colorMap[theme] || colorMap['light'];
}