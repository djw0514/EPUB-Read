import React, { useState, useEffect } from 'react';
import { X, ChevronLeft, ChevronRight, BookOpen } from 'lucide-react';

interface ReadingProgressProps {
  locations: any[];
  currentLocation: any;
  percentage: number;
  onLocationSelect: (cfi: string) => void;
  onClose: () => void;
  isOpen?: boolean;
}

export const ReadingProgress: React.FC<ReadingProgressProps> = ({
  locations,
  currentLocation,
  percentage,
  onLocationSelect,
  onClose,
  isOpen = true
}) => {
  const [selectedLocation, setSelectedLocation] = useState<any>(null);

  useEffect(() => {
    if (currentLocation) {
      setSelectedLocation(currentLocation);
    }
  }, [currentLocation]);

  const handleLocationClick = (location: any) => {
    setSelectedLocation(location);
    const cfi = location.start ? location.start.cfi : location.cfi;
    onLocationSelect(cfi);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-center justify-center p-4"
      onKeyDown={handleKeyDown}
    >
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* 头部 */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              阅读进度
            </h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              当前进度: {Math.round(percentage)}%
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 进度概览 */}
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
              整体进度
            </span>
            <span className="text-sm text-gray-500 dark:text-gray-400">
              {Math.round(percentage)}%
            </span>
          </div>
          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
            <div 
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${percentage}%` }}
            />
          </div>
        </div>

        {/* 章节列表 */}
        <div className="overflow-y-auto max-h-96 p-6">
          {locations.length === 0 ? (
            <div className="text-center py-8">
              <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 dark:text-gray-400">
                正在加载章节信息...
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {locations.map((location, index) => {
                const isSelected = selectedLocation?.start?.cfi === location.start?.cfi;
                const locationPercentage = location.start?.percentage 
                  ? location.start.percentage * 100 
                  : 0;
                
                return (
                  <div
                    key={index}
                    onClick={() => handleLocationClick(location)}
                    className={`
                      p-4 rounded-lg cursor-pointer transition-all duration-200 border
                      ${isSelected 
                        ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' 
                        : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50'
                      }
                    `}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-xs text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded">
                            第 {index + 1} 章
                          </span>
                          {isSelected && (
                            <span className="text-xs text-blue-600 dark:text-blue-400 font-medium">
                              当前章节
                            </span>
                          )}
                        </div>
                        
                        <h3 className="text-sm font-medium text-gray-900 dark:text-white mb-1">
                          {location.start?.label || location.label || `章节 ${index + 1}`}
                        </h3>
                        
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          {location.start?.href || location.href || ''}
                        </p>
                      </div>
                      
                      <div className="flex items-center gap-2 ml-4">
                        <span className="text-xs text-gray-500 dark:text-gray-400">
                          {Math.round(locationPercentage)}%
                        </span>
                        <div className="w-12 bg-gray-200 dark:bg-gray-700 rounded-full h-1.5">
                          <div 
                            className={`
                              h-1.5 rounded-full transition-all duration-300
                              ${isSelected ? 'bg-blue-600' : 'bg-gray-400'}
                            `}
                            style={{ width: `${locationPercentage}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* 底部操作 */}
        <div className="flex items-center justify-between p-6 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50">
          <div className="text-sm text-gray-500 dark:text-gray-400">
            总共 {locations.length} 个章节
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors"
            >
              关闭
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};