import React from 'react';
import { ArrowLeft, Settings, BarChart3, Maximize, Minimize } from 'lucide-react';

interface ReaderToolbarProps {
  book: {
    title: string;
    author: string;
  };
  onBack: () => void;
  onSettings: () => void;
  onProgress: () => void;
  onToggleFullscreen: () => void;
  isFullscreen: boolean;
  percentage: number;
}

export const ReaderToolbar: React.FC<ReaderToolbarProps> = ({
  book,
  onBack,
  onSettings,
  onProgress,
  onToggleFullscreen,
  isFullscreen,
  percentage
}) => {
  return (
    <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-3">
      <div className="flex items-center justify-between">
        {/* 左侧 - 返回和书籍信息 */}
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            title="返回书架"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          
          <div className="min-w-0">
            <h1 className="text-sm font-medium text-gray-900 dark:text-white truncate">
              {book.title}
            </h1>
            <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
              {book.author}
            </p>
          </div>
        </div>

        {/* 右侧 - 工具按钮 */}
        <div className="flex items-center gap-2">
          {/* 进度按钮 */}
          <button
            onClick={onProgress}
            className="flex items-center gap-1 px-3 py-1 text-xs font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <BarChart3 className="w-4 h-4" />
            <span>{Math.round(percentage)}%</span>
          </button>

          {/* 设置按钮 */}
          <button
            onClick={onSettings}
            className="p-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            title="设置"
          >
            <Settings className="w-5 h-5" />
          </button>

          {/* 全屏切换按钮 */}
          <button
            onClick={onToggleFullscreen}
            className="p-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            title={isFullscreen ? "退出全屏" : "全屏阅读"}
          >
            {isFullscreen ? (
              <Minimize className="w-5 h-5" />
            ) : (
              <Maximize className="w-5 h-5" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
};