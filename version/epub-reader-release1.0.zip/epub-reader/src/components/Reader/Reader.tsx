import React, { useState, useEffect } from 'react';
import { ArrowLeft, Settings, Book } from 'lucide-react';
import { Book as BookType } from '../../lib/database';
import { useReader } from '../../hooks/useReader';
import { useReaderSettings } from '../../hooks/useLibrary';
import { ReaderContent } from './ReaderContent';
import { ReaderToolbar } from './ReaderToolbar';
import { ReadingProgress } from './ReadingProgress';
import { SettingsPanel } from '../Settings/SettingsPanel';

interface ReaderProps {
  book: BookType;
  onBack: () => void;
}

export const Reader: React.FC<ReaderProps> = ({ book, onBack }) => {
  const [showSettings, setShowSettings] = useState(false);
  const [showProgress, setShowProgress] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  
  const { settings } = useReaderSettings();
  const {
    bookInstance,
    currentLocation,
    locations,
    isLoading,
    error,
    percentage,
    chapterTitle,
    nextPage,
    prevPage,
    saveProgress
  } = useReader(book);

  // 全屏管理
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  // 点击左右区域翻页
  const handleContentClick = (e: React.MouseEvent) => {
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const width = rect.width;
    
    // 点击左侧区域上一页，右侧区域下一页
    if (clickX < width * 0.3) {
      prevPage();
    } else if (clickX > width * 0.7) {
      nextPage();
    }
  };

  // 键盘快捷键
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'Escape':
          if (isFullscreen) {
            document.exitFullscreen();
          } else {
            onBack();
          }
          break;
        case 's':
        case 'S':
          if (e.ctrlKey || e.metaKey) {
            e.preventDefault();
            setShowSettings(!showSettings);
          }
          break;
        case 'f':
        case 'F':
          if (e.ctrlKey || e.metaKey) {
            e.preventDefault();
            toggleFullscreen();
          }
          break;
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [showSettings, isFullscreen, onBack]);

  const toggleFullscreen = () => {
    if (!isFullscreen) {
      document.documentElement.requestFullscreen();
    } else {
      document.exitFullscreen();
    }
  };

  // 错误处理
  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center max-w-md">
          <Book className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
            阅读器错误
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            {error}
          </p>
          <div className="space-y-2">
            <button
              onClick={onBack}
              className="w-full px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
            >
              返回书架
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`
      relative h-screen bg-white dark:bg-gray-900 overflow-hidden
      ${isFullscreen ? 'fullscreen' : ''}
    `}>
      {/* 顶部工具栏 */}
      {!isFullscreen && (
        <div className="absolute top-0 left-0 right-0 z-20 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between px-4 py-3">
            <div className="flex items-center gap-3">
              <button
                onClick={onBack}
                className="p-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                title="返回书架 (ESC)"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div className="min-w-0">
                <h1 className="text-sm font-medium text-gray-900 dark:text-white truncate">
                  {book.title}
                </h1>
                <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
                  {book.author}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowProgress(!showProgress)}
                className={`
                  px-3 py-1 text-xs font-medium rounded-lg transition-colors
                  ${showProgress 
                    ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/20 dark:text-blue-300' 
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                  }
                `}
              >
                进度 {Math.round(percentage)}%
              </button>
              <button
                onClick={() => setShowSettings(!showSettings)}
                className={`
                  p-2 rounded-lg transition-colors
                  ${showSettings 
                    ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/20 dark:text-blue-300' 
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                  }
                `}
                title="设置 (Ctrl+S)"
              >
                <Settings className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 阅读器主体 */}
      <div className={`
        ${isFullscreen ? 'h-full' : 'h-full pt-16'}
        relative overflow-hidden
      `}>
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <p className="text-gray-600 dark:text-gray-400">加载中...</p>
            </div>
          </div>
        ) : bookInstance ? (
          <div 
            className="h-full relative cursor-pointer"
            onClick={handleContentClick}
          >
            <ReaderContent
              book={bookInstance}
              settings={settings}
              onNextPage={nextPage}
              onPrevPage={prevPage}
            />
            
            {/* 全屏模式下的浮动工具栏 */}
            {isFullscreen && (
              <div className="absolute top-4 left-4 right-4 z-10 flex items-center justify-between pointer-events-none">
                <button
                  onClick={onBack}
                  className="p-2 bg-black bg-opacity-50 text-white rounded-lg hover:bg-opacity-70 transition-colors pointer-events-auto"
                  title="返回书架 (ESC)"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                
                <div className="flex items-center gap-2 pointer-events-auto">
                  <button
                    onClick={() => setShowProgress(!showProgress)}
                    className="px-3 py-1 bg-black bg-opacity-50 text-white text-sm rounded-lg hover:bg-opacity-70 transition-colors"
                  >
                    {Math.round(percentage)}%
                  </button>
                  <button
                    onClick={() => setShowSettings(!showSettings)}
                    className="p-2 bg-black bg-opacity-50 text-white rounded-lg hover:bg-opacity-70 transition-colors"
                  >
                    <Settings className="w-5 h-5" />
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <Book className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 dark:text-gray-400">
                正在初始化阅读器...
              </p>
            </div>
          </div>
        )}
      </div>

      {/* 设置面板 */}
      {showSettings && (
        <SettingsPanel
          onClose={() => setShowSettings(false)}
          isOpen={showSettings}
        />
      )}

      {/* 阅读进度面板 */}
      {showProgress && (
        <ReadingProgress
          locations={locations}
          currentLocation={currentLocation}
          percentage={percentage}
          onLocationSelect={(cfi) => {
            // 跳转到指定位置
            // 这里需要实现跳转逻辑
            setShowProgress(false);
          }}
          onClose={() => setShowProgress(false)}
        />
      )}

      {/* 快捷键提示 */}
      <div className="absolute bottom-4 left-4 z-10 text-xs text-gray-400 dark:text-gray-500 bg-black bg-opacity-50 px-2 py-1 rounded opacity-0 hover:opacity-100 transition-opacity">
        <div>← → 翻页 | ESC 返回 | Ctrl+S 设置</div>
      </div>
    </div>
  );
};