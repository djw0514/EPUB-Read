import Dexie, { Table } from 'dexie';

// 定义数据类型
export interface Book {
  id?: number;
  title: string;
  author: string;
  cover?: string; // base64 编码的封面图片
  fileData: string; // base64 编码的 EPUB 文件
  fileName: string;
  fileSize: number;
  addedAt: Date;
  lastOpened?: Date;
}

export interface ReadingProgress {
  id?: number;
  bookId: number;
  cfi: string; // EPUB 定位符
  percentage: number;
  chapterTitle?: string;
  updatedAt: Date;
}

export interface ReaderSettings {
  id?: number;
  fontSize: number;
  fontFamily: string;
  theme: 'light' | 'dark' | 'sepia';
  lineHeight: number;
  margin: number;
  viewMode: 'single' | 'spread';
  lastUpdated: Date;
}

// 创建数据库类
export class EPubReaderDB extends Dexie {
  books!: Table<Book>;
  readingProgress!: Table<ReadingProgress>;
  readerSettings!: Table<ReaderSettings>;

  constructor() {
    super('EPubReaderDB');
    this.version(1).stores({
      books: '++id, title, author, fileName, addedAt, lastOpened',
      readingProgress: '++id, bookId, cfi, percentage, updatedAt',
      readerSettings: '++id, lastUpdated'
    });
  }
}

// 创建数据库实例
export const db = new EPubReaderDB();

// 数据库操作方法
export class DatabaseService {
  // 书籍相关操作
  static async addBook(book: Omit<Book, 'id'>): Promise<number> {
    return await db.books.add(book);
  }

  static async getAllBooks(): Promise<Book[]> {
    return await db.books.orderBy('lastOpened').reverse().toArray();
  }

  static async getBook(id: number): Promise<Book | undefined> {
    return await db.books.get(id);
  }

  static async updateBook(id: number, changes: Partial<Book>): Promise<number> {
    return await db.books.update(id, changes);
  }

  static async deleteBook(id: number): Promise<void> {
    // 删除书籍及其阅读进度
    await db.transaction('rw', db.books, db.readingProgress, async () => {
      await db.books.delete(id);
      await db.readingProgress.where('bookId').equals(id).delete();
    });
  }

  static async searchBooks(query: string): Promise<Book[]> {
    const lowerQuery = query.toLowerCase();
    return await db.books
      .filter(book => 
        book.title.toLowerCase().includes(lowerQuery) ||
        book.author.toLowerCase().includes(lowerQuery)
      )
      .toArray();
  }

  // 阅读进度相关操作
  static async saveReadingProgress(progress: Omit<ReadingProgress, 'id'>): Promise<number> {
    const existing = await db.readingProgress
      .where('bookId')
      .equals(progress.bookId)
      .first();
    
    if (existing) {
      return await db.readingProgress.update(existing.id!, {
        ...progress,
        updatedAt: new Date()
      });
    } else {
      return await db.readingProgress.add(progress);
    }
  }

  static async getReadingProgress(bookId: number): Promise<ReadingProgress | undefined> {
    return await db.readingProgress
      .where('bookId')
      .equals(bookId)
      .first();
  }

  static async deleteReadingProgress(bookId: number): Promise<void> {
    await db.readingProgress.where('bookId').equals(bookId).delete();
  }

  // 设置相关操作
  static async saveReaderSettings(settings: Omit<ReaderSettings, 'id'>): Promise<number> {
    const existing = await db.readerSettings.orderBy('lastUpdated').reverse().first();
    
    if (existing) {
      return await db.readerSettings.update(existing.id!, {
        ...settings,
        lastUpdated: new Date()
      });
    } else {
      return await db.readerSettings.add(settings);
    }
  }

  static async getReaderSettings(): Promise<ReaderSettings | undefined> {
    return await db.readerSettings.orderBy('lastUpdated').reverse().first();
  }

  // 导出/导入功能
  static async exportBooks(): Promise<string> {
    const books = await db.books.toArray();
    return JSON.stringify({
      books,
      exportedAt: new Date().toISOString()
    });
  }

  static async importBooks(jsonData: string): Promise<void> {
    try {
      const data = JSON.parse(jsonData);
      if (data.books && Array.isArray(data.books)) {
        await db.books.bulkAdd(data.books);
      }
    } catch (error) {
      throw new Error('无效的导入文件格式');
    }
  }

  // 清理操作
  static async clearAllData(): Promise<void> {
    await db.transaction('rw', db.books, db.readingProgress, db.readerSettings, async () => {
      await db.books.clear();
      await db.readingProgress.clear();
      await db.readerSettings.clear();
    });
  }

  // 获取统计信息
  static async getStats(): Promise<{
    totalBooks: number;
    totalSize: number;
    recentBooks: number;
  }> {
    const books = await db.books.toArray();
    const totalSize = books.reduce((sum, book) => sum + book.fileSize, 0);
    const recentBooks = books.filter(book => {
      const oneWeekAgo = new Date();
      oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
      return book.addedAt > oneWeekAgo;
    }).length;

    return {
      totalBooks: books.length,
      totalSize,
      recentBooks
    };
  }
}

// 默认设置
export const defaultSettings: Omit<ReaderSettings, 'id'> = {
  fontSize: 16,
  fontFamily: 'serif',
  theme: 'light',
  lineHeight: 1.6,
  margin: 40,
  viewMode: 'single',
  lastUpdated: new Date()
};