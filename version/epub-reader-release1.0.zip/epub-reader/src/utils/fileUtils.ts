import { Book } from '../lib/database';
import ePub from 'epubjs';

/**
 * 将文件转换为Base64编码
 */
export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      // 移除data:application/epub+zip;base64,前缀
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = error => reject(error);
  });
};

/**
 * 从Base64创建EPUB实例
 */
export const createEPUBFromBase64 = (base64Data: string): any => {
  const dataUrl = `data:application/epub+zip;base64,${base64Data}`;
  return ePub(dataUrl);
};

/**
 * 解析EPUB书籍元数据
 */
export const parseEPUBMetaData = async (base64Data: string): Promise<{
  title: string;
  author: string;
  cover?: string;
}> => {
  try {
    const book = createEPUBFromBase64(base64Data);
    
    // 等待书籍加载完成
    await new Promise<void>((resolve, reject) => {
      book.ready(() => {
        // 检查book是否有效
        if (!book.loaded) {
          reject(new Error('EPUB加载失败'));
          return;
        }
        resolve();
      });
    });

    // 获取元数据
    const metadata = await book.loaded.metadata;
    const title = metadata?.title || '未知标题';
    const author = metadata?.creator || '未知作者';

    // 尝试获取封面
    let cover: string | undefined;
    try {
      if (typeof book.coverUrl === 'function') {
        const coverUrl = await book.coverUrl();
        if (coverUrl) {
          // 将封面URL转换为base64
          cover = await urlToBase64(coverUrl);
        }
      }
    } catch (error) {
      console.warn('无法获取封面:', error);
    }

    // 清理资源
    if (typeof book.destroy === 'function') {
      book.destroy();
    }
    
    return { title, author, cover };
  } catch (error) {
    console.error('解析EPUB元数据失败:', error);
    // 返回默认值而不是抛出错误
    return { title: '未知标题', author: '未知作者' };
  }
};

/**
 * 将URL转换为Base64
 */
export const urlToBase64 = (url: string): Promise<string> => {
  return new Promise((resolve, reject) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();
    
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      ctx?.drawImage(img, 0, 0);
      
      try {
        const dataURL = canvas.toDataURL('image/jpeg', 0.8);
        const base64 = dataURL.split(',')[1];
        resolve(base64);
      } catch (error) {
        reject(error);
      }
    };
    
    img.onerror = () => reject(new Error('图片加载失败'));
    img.src = url;
  });
};

/**
 * 格式化文件大小
 */
export const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

/**
 * 格式化时间
 */
export const formatDate = (date: Date): string => {
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) return `${days}天前`;
  if (hours > 0) return `${hours}小时前`;
  if (minutes > 0) return `${minutes}分钟前`;
  return '刚刚';
};

/**
 * 验证EPUB文件
 */
export const validateEPUBFile = (file: File): { valid: boolean; error?: string } => {
  // 检查文件扩展名
  if (!file.name.toLowerCase().endsWith('.epub')) {
    return { valid: false, error: '请选择EPUB格式的文件' };
  }
  
  // 检查文件大小 (最大100MB)
  const maxSize = 100 * 1024 * 1024;
  if (file.size > maxSize) {
    return { valid: false, error: '文件大小不能超过100MB' };
  }
  
  // 检查文件类型
  if (!file.type.includes('epub') && file.type !== 'application/octet-stream') {
    return { valid: false, error: '文件类型不正确' };
  }
  
  return { valid: true };
};

/**
 * 生成书籍ID
 */
export const generateBookId = (): number => {
  return Date.now() + Math.floor(Math.random() * 1000);
};

/**
 * 截断文本
 */
export const truncateText = (text: string, maxLength: number): string => {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
};

/**
 * 搜索高亮
 */
export const highlightSearchTerm = (text: string, searchTerm: string): string => {
  if (!searchTerm) return text;
  
  const regex = new RegExp(`(${searchTerm})`, 'gi');
  return text.replace(regex, '<mark>$1</mark>');
};

/**
 * 计算阅读时间
 */
export const calculateReadingTime = (wordCount: number): string => {
  const wordsPerMinute = 200; // 平均阅读速度
  const minutes = Math.ceil(wordCount / wordsPerMinute);
  
  if (minutes < 60) {
    return `约${minutes}分钟`;
  } else {
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return `约${hours}小时${remainingMinutes}分钟`;
  }
};

/**
 * 检测设备类型
 */
export const isMobile = (): boolean => {
  return window.innerWidth < 768;
};

/**
 * 格式化百分比
 */
export const formatPercentage = (value: number): string => {
  return `${Math.round(value)}%`;
};