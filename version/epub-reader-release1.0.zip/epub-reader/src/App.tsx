import React, { useState, useEffect } from 'react';
import { Book } from './lib/database';
import { Library } from './components/Library/Library';
import { Reader } from './components/Reader/Reader';
import { ErrorBoundary } from './components/ErrorBoundary';
import { NotificationContainer } from './components/NotificationContainer';
import { useTheme } from './hooks/useLibrary';
import './App.css';

// 应用类型
type AppView = 'library' | 'reader';

function App() {
  const [currentView, setCurrentView] = useState<AppView>('library');
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const { currentTheme } = useTheme();

  // 处理书籍选择
  const handleBookSelect = (book: Book) => {
    setSelectedBook(book);
    setCurrentView('reader');
  };

  // 处理返回书架
  const handleBackToLibrary = () => {
    setCurrentView('library');
    setSelectedBook(null);
  };

  // 应用主题到DOM
  useEffect(() => {
    document.documentElement.classList.remove('light', 'dark', 'sepia');
    document.documentElement.classList.add(currentTheme);
  }, [currentTheme]);

  return (
    <ErrorBoundary>
      <div className={`min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-200 ${currentTheme}`}>
        {/* 主内容区域 */}
        <div className="app-container">
          {currentView === 'library' && (
            <Library onBookSelect={handleBookSelect} />
          )}
          
          {currentView === 'reader' && selectedBook && (
            <Reader 
              book={selectedBook} 
              onBack={handleBackToLibrary}
            />
          )}
        </div>

        {/* 全局加载指示器 */}
        <div id="global-loading" className="hidden fixed inset-0 z-50 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 flex items-center gap-3">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
            <span className="text-gray-900 dark:text-white">加载中...</span>
          </div>
        </div>

        {/* 全局通知 */}
        <NotificationContainer />
      </div>
    </ErrorBoundary>
  );
}

export default App;