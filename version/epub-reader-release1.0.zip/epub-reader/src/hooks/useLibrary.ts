import { useState, useEffect } from 'react';
import { Book, ReaderSettings, DatabaseService, defaultSettings } from '../lib/database';

/**
 * 书架管理Hook
 */
export const useLibrary = () => {
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // 加载所有书籍
  const loadBooks = async () => {
    setLoading(true);
    setError(null);
    try {
      const booksData = await DatabaseService.getAllBooks();
      setBooks(booksData);
    } catch (err) {
      setError('加载书籍失败');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // 添加书籍
  const addBook = async (bookData: Omit<Book, 'id'>) => {
    try {
      const id = await DatabaseService.addBook(bookData);
      await loadBooks(); // 重新加载书籍列表
      return id;
    } catch (err) {
      setError('添加书籍失败');
      throw err;
    }
  };

  // 删除书籍
  const deleteBook = async (id: number) => {
    try {
      await DatabaseService.deleteBook(id);
      await loadBooks(); // 重新加载书籍列表
    } catch (err) {
      setError('删除书籍失败');
      throw err;
    }
  };

  // 更新书籍
  const updateBook = async (id: number, changes: Partial<Book>) => {
    try {
      await DatabaseService.updateBook(id, changes);
      await loadBooks(); // 重新加载书籍列表
    } catch (err) {
      setError('更新书籍失败');
      throw err;
    }
  };

  // 搜索书籍
  const searchBooks = async (query: string) => {
    if (!query.trim()) {
      await loadBooks();
      return;
    }
    
    try {
      const results = await DatabaseService.searchBooks(query);
      setBooks(results);
    } catch (err) {
      setError('搜索失败');
    }
  };

  // 初始化时加载书籍
  useEffect(() => {
    loadBooks();
  }, []);

  return {
    books,
    loading,
    error,
    loadBooks,
    addBook,
    deleteBook,
    updateBook,
    searchBooks,
    setError
  };
};

/**
 * 阅读器设置Hook
 */
export const useReaderSettings = () => {
  const [settings, setSettings] = useState<ReaderSettings>(defaultSettings);
  const [loading, setLoading] = useState(false);

  // 加载设置
  const loadSettings = async () => {
    setLoading(true);
    try {
      const savedSettings = await DatabaseService.getReaderSettings();
      if (savedSettings) {
        setSettings(savedSettings);
      }
    } catch (err) {
      console.error('加载设置失败:', err);
    } finally {
      setLoading(false);
    }
  };

  // 保存设置
  const saveSettings = async (newSettings: Partial<ReaderSettings>) => {
    try {
      const updatedSettings = { ...settings, ...newSettings, lastUpdated: new Date() };
      await DatabaseService.saveReaderSettings(updatedSettings);
      setSettings(updatedSettings);
    } catch (err) {
      console.error('保存设置失败:', err);
      throw err;
    }
  };

  // 重置设置
  const resetSettings = async () => {
    try {
      await DatabaseService.saveReaderSettings(defaultSettings);
      setSettings(defaultSettings);
    } catch (err) {
      console.error('重置设置失败:', err);
      throw err;
    }
  };

  // 初始化时加载设置
  useEffect(() => {
    loadSettings();
  }, []);

  return {
    settings,
    loading,
    saveSettings,
    resetSettings,
    loadSettings
  };
};

/**
 * 主题管理Hook
 */
export const useTheme = () => {
  const { settings, saveSettings } = useReaderSettings();

  const applyTheme = (theme: 'light' | 'dark' | 'sepia') => {
    // 移除所有主题类
    document.documentElement.classList.remove('light', 'dark', 'sepia');
    
    // 添加新主题类
    document.documentElement.classList.add(theme);
    
    // 保存到设置
    saveSettings({ theme });
  };

  // 初始化时应用主题
  useEffect(() => {
    applyTheme(settings.theme);
  }, [settings.theme]);

  return {
    currentTheme: settings.theme,
    setTheme: applyTheme
  };
};

/**
 * 本地存储Hook
 */
export const useLocalStorage = <T>(key: string, defaultValue: T) => {
  const [value, setValue] = useState<T>(() => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch (err) {
      console.error(`读取本地存储失败 (${key}):`, err);
      return defaultValue;
    }
  });

  const setStoredValue = (newValue: T | ((val: T) => T)) => {
    try {
      const valueToStore = newValue instanceof Function ? newValue(value) : newValue;
      setValue(valueToStore);
      localStorage.setItem(key, JSON.stringify(valueToStore));
    } catch (err) {
      console.error(`保存到本地存储失败 (${key}):`, err);
    }
  };

  return [value, setStoredValue] as const;
};

/**
 * 文件上传Hook
 */
export const useFileUpload = () => {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);

  const uploadFile = async (
    file: File,
    onProgress?: (progress: number) => void
  ): Promise<string> => {
    setUploading(true);
    setProgress(0);

    try {
      // 模拟进度更新
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          const newProgress = prev + Math.random() * 20;
          if (newProgress >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return newProgress;
        });
        onProgress?.(progress);
      }, 100);

      // 实际的转换逻辑在组件中处理
      return new Promise((resolve, reject) => {
        // 这里只是占位，实际实现在组件中
        setTimeout(() => {
          clearInterval(progressInterval);
          setProgress(100);
          resolve('');
        }, 2000);
      });
    } catch (err) {
      console.error('文件上传失败:', err);
      throw err;
    } finally {
      setUploading(false);
    }
  };

  return {
    uploading,
    progress,
    uploadFile
  };
};

/**
 * 拖拽Hook
 */
export const useDragAndDrop = (onDrop: (files: FileList) => void) => {
  const [isDragOver, setIsDragOver] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      onDrop(files);
    }
  };

  return {
    isDragOver,
    dragProps: {
      onDragOver: handleDragOver,
      onDragLeave: handleDragLeave,
      onDrop: handleDrop
    }
  };
};