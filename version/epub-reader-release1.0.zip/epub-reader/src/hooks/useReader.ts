import { useState, useEffect, useCallback, useRef } from 'react';
import ePub from 'epubjs';
import { Book, ReadingProgress, DatabaseService } from '../lib/database';
import { useReaderSettings } from './useLibrary';

interface UseReaderReturn {
  bookInstance: any | null;
  currentLocation: any;
  locations: any[];
  isLoading: boolean;
  error: string | null;
  totalLocations: number;
  percentage: number;
  chapterTitle: string;
  goToLocation: (cfi: string) => void;
  nextPage: () => void;
  prevPage: () => void;
  saveProgress: () => Promise<void>;
}

export const useReader = (book: Book | null): UseReaderReturn => {
  const [bookInstance, setBookInstance] = useState<any | null>(null);
  const [currentLocation, setCurrentLocation] = useState<any>(null);
  const [locations, setLocations] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [totalLocations, setTotalLocations] = useState(0);
  const [percentage, setPercentage] = useState(0);
  const [chapterTitle, setChapterTitle] = useState('');
  
  const { settings } = useReaderSettings();
  const progressSaveTimeout = useRef<NodeJS.Timeout>();
  const isInitialized = useRef(false);

  // 初始化书籍
  const initializeBook = useCallback(async () => {
    if (!book || isInitialized.current) return;

    setIsLoading(true);
    setError(null);

    try {
      // 创建EPUB实例
      const dataUrl = `data:application/epub+zip;base64,${book.fileData}`;
      const bookDoc = ePub(dataUrl) as any;
      
      // 等待书籍加载完成 - 修复API调用
      await new Promise<void>((resolve, reject) => {
        if (!bookDoc.ready) {
          reject(new Error('EPUB实例创建失败'));
          return;
        }
        
        bookDoc.ready().then(() => {
          resolve();
        }).catch(reject);
      });

      // 加载位置信息
      await bookDoc.loaded.navigation;
      await bookDoc.loaded.metadata;

      // 获取位置列表
      const locationList = await bookDoc.locations.generate(1000);
      setLocations(locationList);
      setTotalLocations(locationList.length);

      // 恢复阅读进度
      const savedProgress = await DatabaseService.getReadingProgress(book.id!);
      if (savedProgress) {
        await bookDoc.goToLocation(savedProgress.cfi);
        const location = bookDoc.currentLocation();
        setCurrentLocation(location);
        setPercentage(savedProgress.percentage);
        setChapterTitle(savedProgress.chapterTitle || '');
      } else {
        // 从开头开始
        const location = bookDoc.currentLocation();
        setCurrentLocation(location);
        setPercentage(0);
        setChapterTitle('');
      }

      // 监听位置变化
      bookDoc.on('relocated', (location: any) => {
        setCurrentLocation(location);
        setPercentage(location.start && location.start.percentage ? location.start.percentage * 100 : 0);
        setChapterTitle(location.start && location.start.href ? location.start.href.split('#')[0] : '');
        
        // 防抖保存进度
        if (progressSaveTimeout.current) {
          clearTimeout(progressSaveTimeout.current);
        }
        progressSaveTimeout.current = setTimeout(() => {
          saveProgress();
        }, 2000);
      });

      setBookInstance(bookDoc);
      isInitialized.current = true;
    } catch (err) {
      console.error('初始化书籍失败:', err);
      setError('加载书籍失败，请重试');
    } finally {
      setIsLoading(false);
    }
  }, [book]);

  // 跳转到指定位置
  const goToLocation = useCallback(async (cfi: string) => {
    if (!bookInstance) return;
    
    try {
      await bookInstance.goTo(cfi);
    } catch (err) {
      console.error('跳转失败:', err);
    }
  }, [bookInstance]);

  // 下一页
  const nextPage = useCallback(async () => {
    if (!bookInstance) return;
    
    try {
      await bookInstance.next();
    } catch (err) {
      console.error('下一页失败:', err);
    }
  }, [bookInstance]);

  // 上一页
  const prevPage = useCallback(async () => {
    if (!bookInstance) return;
    
    try {
      await bookInstance.prev();
    } catch (err) {
      console.error('上一页失败:', err);
    }
  }, [bookInstance]);

  // 保存阅读进度
  const saveProgress = useCallback(async () => {
    if (!bookInstance || !book || !currentLocation) return;

    try {
      const cfi = currentLocation.start ? currentLocation.start.cfi : '';
      const currentPercentage = currentLocation.start && currentLocation.start.percentage 
        ? currentLocation.start.percentage * 100 
        : percentage;

      if (cfi) {
        await DatabaseService.saveReadingProgress({
          bookId: book.id!,
          cfi,
          percentage: currentPercentage,
          chapterTitle,
          updatedAt: new Date()
        });

        // 更新书籍的最后阅读时间
        await DatabaseService.updateBook(book.id!, {
          lastOpened: new Date()
        });
      }
    } catch (err) {
      console.error('保存阅读进度失败:', err);
    }
  }, [bookInstance, book, currentLocation, percentage, chapterTitle]);

  // 键盘事件处理
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (!bookInstance) return;

      switch (e.key) {
        case 'ArrowLeft':
        case 'ArrowUp':
          e.preventDefault();
          prevPage();
          break;
        case 'ArrowRight':
        case 'ArrowDown':
        case ' ':
          e.preventDefault();
          nextPage();
          break;
        case 'Home':
          e.preventDefault();
          goToLocation('epubcfi(/0)');
          break;
        case 'End':
          e.preventDefault();
          if (locations.length > 0) {
            const lastLocation = locations[locations.length - 1];
            goToLocation(lastLocation);
          }
          break;
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [bookInstance, nextPage, prevPage, goToLocation, locations]);

  // 鼠标滚轮事件处理
  useEffect(() => {
    const handleWheel = (e: WheelEvent) => {
      if (!bookInstance) return;

      // 避免在设置面板上触发
      if ((e.target as HTMLElement).closest('.settings-panel')) {
        return;
      }

      e.preventDefault();
      
      if (e.deltaY > 0) {
        nextPage();
      } else {
        prevPage();
      }
    };

    window.addEventListener('wheel', handleWheel, { passive: false });
    return () => window.removeEventListener('wheel', handleWheel);
  }, [bookInstance, nextPage, prevPage]);

  // 清理函数
  useEffect(() => {
    return () => {
      if (bookInstance) {
        bookInstance.destroy();
      }
      if (progressSaveTimeout.current) {
        clearTimeout(progressSaveTimeout.current);
      }
    };
  }, [bookInstance]);

  // 初始化书籍
  useEffect(() => {
    if (book) {
      isInitialized.current = false;
      initializeBook();
    }
  }, [book, initializeBook]);

  // 应用设置变化
  useEffect(() => {
    if (bookInstance && currentLocation) {
      // 应用字体大小
      const content = bookInstance.renderTo('viewer', {
        width: '100%',
        height: '100%',
        spread: settings.viewMode === 'spread' ? 'always' : 'none'
      });

      // 设置CSS变量
      document.documentElement.style.setProperty('--reader-font-size', `${settings.fontSize}px`);
      document.documentElement.style.setProperty('--reader-font-family', settings.fontFamily);
      document.documentElement.style.setProperty('--reader-line-height', settings.lineHeight.toString());
      document.documentElement.style.setProperty('--reader-margin', `${settings.margin}px`);
    }
  }, [bookInstance, settings, currentLocation]);

  return {
    bookInstance,
    currentLocation,
    locations,
    isLoading,
    error,
    totalLocations,
    percentage,
    chapterTitle,
    goToLocation,
    nextPage,
    prevPage,
    saveProgress
  };
};